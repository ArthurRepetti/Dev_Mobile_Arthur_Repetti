
export interface Personne {
  _id: number;
  date_naissance: string;
  nom: string;
  prenom: string;
  pseudo: string;
  sexe: string;

}
