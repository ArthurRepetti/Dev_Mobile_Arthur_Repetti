
export interface Participant {
  nom: string; // Le nom du participant (string)
  prenom: string; // Le prenom du participant (string)

}
